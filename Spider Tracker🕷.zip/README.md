# Spider Tracker

Spider Tracker est un exemple de **crawler web** développé avec Node.js et Express.

## Fonctionnalités

- Analyse d'une URL
- Extraction du titre de la page
- Extraction de la description
- Extraction des mots-clés
- Liste des liens présents sur la page
- Liste des images
- API REST
- Interface Web

## Installation

```bash
npm install
```

## Démarrage

```bash
npm start
```

Mode développement :

```bash
npm run dev
```

Le serveur sera accessible sur :

```
http://localhost:3000
```

## Structure

```
spider-tracker/
│
├── controllers/
├── routes/
├── services/
├── utils/
├── public/
├── package.json
├── index.js
├── config.js
└── .env
```

## Licence

MIT