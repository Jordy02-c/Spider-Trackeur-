import dotenv from "dotenv";

dotenv.config();

const config = {
  app: {
    name: process.env.APP_NAME || "Spider Tracker",
    port: process.env.PORT || 3000,
    env: process.env.NODE_ENV || "development"
  },

  crawler: {
    userAgent:
      process.env.USER_AGENT ||
      "SpiderTrackerBot/1.0 (+https://localhost)",

    timeout: Number(process.env.TIMEOUT) || 10000,

    maxPages: Number(process.env.MAX_PAGES) || 20
  }
};

export default config;