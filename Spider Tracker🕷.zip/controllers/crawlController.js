import { crawlWebsiteData } from "../services/crawler.js";

/**
 * GET /api/crawl/status
 */
export const getStatus = (req, res) => {
  res.json({
    success: true,
    service: "Spider Tracker",
    version: "1.0.0",
    status: "online",
    timestamp: new Date().toISOString()
  });
};

/**
 * POST /api/crawl
 * Body:
 * {
 *   "url": "https://example.com"
 * }
 */
export const crawlWebsite = async (req, res) => {
  try {
    const { url } = req.body;

    if (!url) {
      return res.status(400).json({
        success: false,
        message: "Le champ 'url' est obligatoire."
      });
    }

    let parsedUrl;

    try {
      parsedUrl = new URL(url);
    } catch {
      return res.status(400).json({
        success: false,
        message: "URL invalide."
      });
    }

    if (!["http:", "https:"].includes(parsedUrl.protocol)) {
      return res.status(400).json({
        success: false,
        message: "Seuls les protocoles HTTP et HTTPS sont autorisés."
      });
    }

    const result = await crawlWebsiteData(parsedUrl.href);

    res.json({
      success: true,
      data: result
    });

  } catch (error) {
    console.error(error);

    res.status(500).json({
      success: false,
      message: "Erreur lors de l'exploration du site.",
      error: error.message
    });
  }
};