import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";

import config from "./config.js";
import crawlRoutes from "./routes/crawl.js";

const app = express();

// Middlewares
app.use(cors());
app.use(helmet());
app.use(morgan("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Fichiers statiques
app.use(express.static("public"));

// Route principale
app.get("/", (req, res) => {
  res.sendFile(process.cwd() + "/public/index.html");
});

// API
app.use("/api/crawl", crawlRoutes);

// Gestion des erreurs 404
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "Route introuvable"
  });
});

// Démarrage du serveur
app.listen(config.app.port, () => {
  console.log(`
====================================
🕷 ${config.app.name}
====================================
🚀 Serveur lancé
🌐 http://localhost:${config.app.port}
⚙️ Mode : ${config.app.env}
====================================
`);
});