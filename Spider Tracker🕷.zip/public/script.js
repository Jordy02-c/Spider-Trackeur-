const urlInput = document.getElementById("url");
const crawlBtn = document.getElementById("crawlBtn");
const loading = document.getElementById("loading");
const result = document.getElementById("result");

crawlBtn.addEventListener("click", crawlWebsite);

async function crawlWebsite() {
    const url = urlInput.value.trim();

    if (!url) {
        alert("Veuillez entrer une URL.");
        return;
    }

    loading.classList.remove("hidden");
    crawlBtn.disabled = true;
    result.textContent = "";

    try {
        const response = await fetch("/api/crawl", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ url })
        });

        const data = await response.json();

        if (!data.success) {
            result.textContent = `Erreur : ${data.message}`;
            return;
        }

        const info = data.data;

        result.textContent =
`🕷 Spider Tracker

URL :
${info.url}

Titre :
${info.title || "Aucun"}

Description :
${info.description || "Aucune"}

Mots-clés :
${info.keywords || "Aucun"}

Nombre de liens :
${info.linksFound}

Nombre d'images :
${info.imageCount}

Date d'analyse :
${info.crawledAt}`;
    } catch (err) {
        result.textContent = `Erreur : ${err.message}`;
    } finally {
        loading.classList.add("hidden");
        crawlBtn.disabled = false;
    }
}