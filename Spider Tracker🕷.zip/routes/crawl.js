import express from "express";
import {
  crawlWebsite,
  getStatus
} from "../controllers/crawlController.js";

const router = express.Router();

/**
 * GET /api/crawl/status
 * Vérifie que l'API fonctionne.
 */
router.get("/status", getStatus);

/**
 * POST /api/crawl
 * Corps attendu :
 * {
 *   "url": "https://example.com"
 * }
 */
router.post("/", crawlWebsite);

export default router;