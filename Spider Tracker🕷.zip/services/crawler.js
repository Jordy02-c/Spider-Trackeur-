import axios from "axios";
import * as cheerio from "cheerio";
import config from "../config.js";

export async function crawlWebsiteData(url) {
  const response = await axios.get(url, {
    timeout: config.crawler.timeout,
    headers: {
      "User-Agent": config.crawler.userAgent
    },
    maxRedirects: 5
  });

  const html = response.data;
  const $ = cheerio.load(html);

  // Titre
  const title = $("title").first().text().trim();

  // Description
  const description =
    $('meta[name="description"]').attr("content") ||
    $('meta[property="og:description"]').attr("content") ||
    "";

  // Mots-clés
  const keywords =
    $('meta[name="keywords"]').attr("content") || "";

  // Liens
  const links = [];

  $("a[href]").each((_, element) => {
    const href = $(element).attr("href");
    const text = $(element).text().trim();

    if (href && links.length < config.crawler.maxPages) {
      links.push({
        text,
        href
      });
    }
  });

  // Images
  const images = [];

  $("img[src]").each((_, element) => {
    const src = $(element).attr("src");

    if (src && images.length < 20) {
      images.push(src);
    }
  });

  return {
    url,
    title,
    description,
    keywords,
    linksFound: links.length,
    imageCount: images.length,
    links,
    images,
    crawledAt: new Date().toISOString()
  };
}