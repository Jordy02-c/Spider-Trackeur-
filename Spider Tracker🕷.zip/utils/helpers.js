/**
 * Vérifie si une chaîne est une URL HTTP/HTTPS valide.
 */
export function isValidUrl(value) {
  try {
    const url = new URL(value);

    return (
      url.protocol === "http:" ||
      url.protocol === "https:"
    );
  } catch {
    return false;
  }
}

/**
 * Nettoie une chaîne de caractères.
 */
export function cleanText(text = "") {
  return text
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Supprime les doublons d'un tableau.
 */
export function unique(array = []) {
  return [...new Set(array)];
}

/**
 * Tronque un texte.
 */
export function truncate(text = "", length = 150) {
  if (text.length <= length) return text;

  return text.substring(0, length) + "...";
}

/**
 * Formate une date ISO.
 */
export function formatDate(date = new Date()) {
  return new Date(date).toLocaleString("fr-FR");
}